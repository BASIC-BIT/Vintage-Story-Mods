﻿namespace thebasics.ModSystems.PlayerStats.Models
{
    public class PlayerStatDefinition
    {
        public string Title;
        public string ID;
    }
}