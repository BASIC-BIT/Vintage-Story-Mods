﻿namespace thebasics.ModSystems.PlayerStats.Models
{
    public enum PlayerStatType
    {
        Deaths,
        PlayerKills,
        NpcKills,
    }
}