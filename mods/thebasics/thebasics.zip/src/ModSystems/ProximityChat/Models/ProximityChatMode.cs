﻿namespace thebasics.Models
{
    public enum ProximityChatMode
    {
        Normal,
        Whisper,
        Yell,
        Sign,
    }
}